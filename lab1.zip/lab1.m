%Ejercicio 1

% Define the custom function for calculating logarithms with a custom base
log_base_c = @(x, c) log(x) / log(c);

% Define the interval
interval = 0:0.01:15*pi;

% A)

% Evaluate polynomials a and b over the interval
a = polyval([5, 15], interval);
b = polyval([2, 0], interval);

% Compute y using the defined formula
y = 6*log_base_c(a, 4) - log_base_c(b, 2);

% Plot y
subplot(5,1,1);
plot(interval, y, 'red *');
xlabel('Interval');
ylabel('y');
title('Plot of y = 6*log_4(5x + 15) - log_2(2x)');

%B)

% Evaluate polynomials a and b over the interval
a = 6*log_base_c(polyval([2, 9], interval),10);
b = 2*log(polyval([1, 16], interval));
c = sin(a) + cos(b);

% Plot c
subplot(5,1,2);
plot(interval, c, 'green +');
xlabel('Interval');
ylabel('c');
% Create a title with the formulas
a_formula = '6 * log_{10}(2x + 9)';
b_formula = '2 * log(x + 16)';
title(['Plot of c = sin(' a_formula ') + cos(' b_formula ') ' ...
    'over the Interval']);

%C) Graph both 

% Plot both y and c
subplot(5,1,3);
plot(interval, y, 'r*', interval, c, 'g+');
xlabel('Interval');
ylabel('Values');
title('Plot of y (red) and c (green) over the Interval');
legend('y', 'c');

%D)
function plot_interval(interval, x, scale_type)
    % Plot x
    plot_func = @plot;
    if strcmp(scale_type, 'logarithmic')
        plot_func = @semilogy;
    end
    
    plot_func(interval, x, 'blue *');
    grid on;
    xlabel('Interval');
    ylabel('x');
    
    % Create a title
    function_str = 'x = 2 * exp(2x + 3)';
    title(['Plot of ' function_str ' over the Interval ' scale_type]);
end

% Define the interval
interval = -10:.05:10;

a = polyval([2 3], interval);
x = 2 * exp(a);

% Plot x Normal
subplot(5,1,4)
plot_interval(interval, x, 'Normal');


% Plot x Logarithmic
subplot(5,1,5)
plot_interval(interval, x, 'logarithmic');


%Ejercicio 2
% A)

function solution = newtonRaphson(polynomial,iterations, initValue, error)
    %derivative of the polynomial
    derivative = polyder(polynomial); 
     % Evaluate polynomial and derivative at initValue
    result = initValue - polyval(polynomial,initValue) / polyval(derivative,initValue); 
   
    relativeError = abs((result - initValue) / result) * 100;
    
    if iterations <= 0 || relativeError < error 
        solution = result;
    else
        solution = newtonRaphson(polynomial,iterations - 1,result,error);
    end
end

%a = [2 4 -6];  
%Define the coefficients of the polynomial
fprintf('Newton Raphson \n');
a = input('ingresa tu funcion polinomica:  ');
b = input('ingresa la cantidad de iteraciones: '); % Number of iterations
c = input('ingresa valor inicial: '); % Initial guess
d = input('ingresa error: '); % Error tolerance
root = newtonRaphson(a, b, c, d); % Call the function 
fprintf('Raiz: %f\n', root);

%roots(a)

%B)

function mean = calculateMean(x)
    totalSum = 0;
    for i = 1:length(x)
        totalSum = totalSum + x(i);
    end
    mean = totalSum / length(x);
end

function stdDev = calculateStd(x)
    meanValue = calculateMean(x);
    totalSum = 0;
    for i = 1:length(x)
        totalSum = totalSum + (x(i) - meanValue)^2;
    end
    stdDev = sqrt(totalSum / (length(x) - 1));
end

fprintf('Desviación Estándar \n');
calculateStd([1 2 2 4])

%std([1 2 2 4])